﻿//Swit alert mensaje
function Mensaje(titulo, detalle, icono) {
    Swal.fire(
        titulo,
        detalle,
        icono
    )
}
//Convertir texto en mayusaculas
function convertirAMayusculasAsync(textBox) {
    var valorActual = textBox.value;
    var valorMayusculas = valorActual.toUpperCase();
    if (valorActual !== valorMayusculas) {
        textBox.value = valorMayusculas;
    }
}
//Validar solo numeros
function validarNumeros(inputField) {
    inputField.addEventListener('keydown', bloquearEspacio);
    inputField.value = inputField.value.replace(/[^0-9]/g, '');
}
//Bloquear espacio 
function bloquearEspacio(event) {
    if (event.key === ' ') {
        event.preventDefault();
    }
}